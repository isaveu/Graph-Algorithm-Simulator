package structures;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ListImplementationIterator<T> implements Iterator<T>
{
	private ListImplementation<T> list;
	private int location = 0;
	
	public ListImplementationIterator(ListImplementation<T> list)
	{
		this.list = list;
	}
	
	@Override
    public T next()
	{
		if (this.hasNext()) 
		{
            return (T) list.get(location++);
        }
		else
		{
            throw new NoSuchElementException();
        }
       
    }

	@Override
	public boolean hasNext()
	{
		// TODO Auto-generated method stub
		return location < list.size();
	}
}
