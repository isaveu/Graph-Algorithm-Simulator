package structures;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * An {@code ListImplementation} is a Linked List that wraps {@link Node}s and
 * provides useful operations.
 * 
 * @author jcollard
 * 
 */
public class ListImplementation<T> implements ListInterface<T> 
{
	private int size = 0;
	private static final int DEFAULT_CAPACITY = 500000;
    private Object elements[];
    
	public ListImplementation() 
	{
		elements = new Object[DEFAULT_CAPACITY];
	}

	/**
	 * Returns the number of nodes in this list.
	 */
	@Override
	public int size()
	{
        return size;
	}

	@Override
	public boolean isEmpty() 
	{
		if(size==0)
			return true;
        return false;
	}

	/**
	 * Appends {@code elem} to the end of this {@code ListImplementation} and
	 * returns itself for convenience.
	 */
	@Override
	public ListImplementation<T> append(T elem)
	{
		if(elem == null) 
		{
			throw new NullPointerException();
		}
		elements[size++] = elem;
        return this;
	}
	

	/**
	 * Gets the {@code n}th element from this list.
	 */
	
	@SuppressWarnings("unchecked")
	@Override
	public T get(int n) 
	{
		if (n>= size || n <0) 
		{
            throw new NoSuchElementException();
        }
		for(int i=0;i<size;i++)
		{
			if(i==n)
			{
				return (T) elements[i];
			}
		}
		return null;
        
	}

	/**
	 * Returns an iterator over this list. The iterator does not support the
	 * {@code remove()} method.
	 */
	@Override
	public Iterator<T> iterator()
	{
        return new ListImplementationIterator<T>(this);
	}
}

