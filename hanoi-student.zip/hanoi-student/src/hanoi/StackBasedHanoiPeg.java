package hanoi;

import structures.LinkedStack;
import structures.ListImplementation;

/**
 * A {@link StackBasedHanoiPeg} is a {@link HanoiPeg} backed by a
 * {@link LinkedStack}
 * 
 * @author jcollard
 *
 */
public class StackBasedHanoiPeg implements HanoiPeg 
{
	
	private int top = 0;
	private ListImplementation<HanoiRing> stack;
	
	/**
	 * Creates a new {@link StackBasedHanoiPeg} that has no rings.
	 */
	public StackBasedHanoiPeg() 
	{
		stack = new ListImplementation<HanoiRing>();
	}

	@Override
	public void addRing(HanoiRing ring) throws IllegalHanoiMoveException 
	{
		if(ring==null)
		{
			throw new NullPointerException();
		}
		else if(top==0)
		{
			stack.append(ring);
			top++;
		}
		else
		{
			int ringValue = ring.getSize();
			int lastRingValue = stack.get(top-1).getSize();
			if(ringValue >= lastRingValue)
			{
				throw new IllegalHanoiMoveException("This ring size is greater than previous one.");
			}
			else
			{
				stack.append(ring);
				top++;
			}
		}
		
		
	}

	@Override
	public HanoiRing remove() throws IllegalHanoiMoveException
	{
		if(!this.hasRings())
		{
			throw new IllegalHanoiMoveException("Stack is empty.");
		}
		else
		{
			--top;
			HanoiRing topRing = stack.get(top);
			ListImplementation<HanoiRing> newStack = new ListImplementation<HanoiRing>();
			for(int i=0;i<top;i++)
			{
				newStack.append(stack.get(i));
			}
			stack = newStack;
			return topRing;
		}
		
	}

	@Override
	public HanoiRing getTopRing() throws IllegalHanoiMoveException
	{
		if(!hasRings())
		{
			throw new IllegalHanoiMoveException("Stack is empty.");
		}
		else
		{
			return stack.get(top-1);
		}
	}

	@Override
	public boolean hasRings()
	{
		if(top<=0)
			return false;
        return true;
	}
	
	public int getSize()
	{
		return top;
	}
}
