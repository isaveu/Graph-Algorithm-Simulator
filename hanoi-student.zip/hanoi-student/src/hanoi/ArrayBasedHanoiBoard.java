package hanoi;

/**
 * A {@link ArrayBasedHanoiBoard} is a simple implementation of
 * {@link HanoiBoard}
 * 
 * @author jcollard
 * 
 */
public class ArrayBasedHanoiBoard implements HanoiBoard
{
	
	private StackBasedHanoiPeg pegs[];
	private int towerSize;
	/**
	 * Creates a {@link ArrayBasedHanoiBoard} with three empty {@link HanoiPeg}s
	 * and {@code n} rings on peg 0.
	 */
	public ArrayBasedHanoiBoard(int n)
	{
		if(n<0)
		{
			throw new IllegalArgumentException();
		}
		else
		{
			this.towerSize = n;
			pegs = new StackBasedHanoiPeg[3];
			for(int i=0;i<3;i++)
			{
				pegs[i] = new StackBasedHanoiPeg();
			}
			for(int i=n;i>=1;i--)
			{
				pegs[0].addRing(new HanoiRing(i));
			}
		}
	}

	@Override
	public void doMove(HanoiMove move) throws IllegalHanoiMoveException 
	{
		if(!isLegalMove(move))
		{
			throw new IllegalHanoiMoveException("You cannot move from a ring that contains no rings.");
		}
		
		HanoiRing ring = pegs[move.getFromPeg()].remove();
		pegs[move.getToPeg()].addRing(ring);
	}

	@Override
	public boolean isSolved()
	{   
		if(this.towerSize==0)
			return true;
		if(pegs[1].getSize()!=towerSize && pegs[2].getSize()!=towerSize)
		{
			return false;
		}
		int f = 0;
		for(int i=1;i<=2;i++)
		{
			f=0;
			if(pegs[i].getSize()==this.towerSize)
			{
				StackBasedHanoiPeg chkPeg = pegs[i];
				for(int j=1;j<=towerSize;j++)
				{
					if(chkPeg.remove().getSize()!=j)
					{
						f=1;
						break;
					}
				}
				if(f==1) break;
			}
		}
		if(f==0) return true;
		
        return false;
	}

	/**
	 * <p>
	 * A {@link HanoiMove} is not legal if either is true:
	 * 
	 * <ul>
	 * <li>The from peg has no rings</li>
	 * <li>The to peg has rings AND the ring to be moved has a size larger than
	 * the topmost ring on the to peg.</li>
	 * </ul>
	 * 
	 * Otherwise, the move is legal.
	 * </p>
	 */
	@Override
	public boolean isLegalMove(HanoiMove move)
	{    
		if(move==null)
		{
			throw new NullPointerException();
		}
		
		if(move.getFromPeg()==move.getToPeg())
		{
			return false;
		}
		else if(!pegs[move.getFromPeg()].hasRings())
		{
			return false;
		}
		else
		{
			int fromRingSize = pegs[move.getFromPeg()].getTopRing().getSize();
			if(pegs[move.getToPeg()].hasRings())
			{
				int toRingSize = pegs[move.getToPeg()].getTopRing().getSize();
				if(fromRingSize >= toRingSize)
				{
					return false;
				}
			}
		}
		return true;
        
	}
}
